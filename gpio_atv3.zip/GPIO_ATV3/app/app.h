/*
 * app.h
 *
 *  Created on: Sep 15, 2021
 *      Author: lcsmr
 */

#ifndef APP_H_
#define APP_H_

void app_init(void);
void app_loop(void);

#endif /* APP_H_ */
