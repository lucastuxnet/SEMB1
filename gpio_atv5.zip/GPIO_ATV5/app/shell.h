/*
 * shell.h
 *
 *  Created on: Sep 16, 2021
 *      Author: lcsmr
 */

#ifndef SHELL_H_
#define SHELL_H_

void shell_init(void);
extern void shell_tick_1ms(void);


#endif /* SHELL_H_ */
