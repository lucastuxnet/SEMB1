/*
 * hw.h
 *
 *  Created on: Sep 15, 2021
 *      Author: lcsmr
 */

#ifndef HW_H_
#define HW_H_

void hw_sleep(void);
void hw_led_toggle(void);

#endif /* HW_H_ */
